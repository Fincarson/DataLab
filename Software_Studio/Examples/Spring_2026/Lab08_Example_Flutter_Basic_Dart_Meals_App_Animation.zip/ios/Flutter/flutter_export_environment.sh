#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=D:\Dev_Environment\SDK\Flutter"
export "FLUTTER_APPLICATION_PATH=D:\Dev_Environment\GitLab\NTHU_Wu_ShanHung\Software_Studio\Examples\Spring_2026\Lab08_Example_Flutter_Basic_Dart_Meals_App_Animation"
export "COCOAPODS_PARALLEL_CODE_SIGN=true"
export "FLUTTER_TARGET=lib\main.dart"
export "FLUTTER_BUILD_DIR=build"
export "FLUTTER_BUILD_NAME=0.1.0"
export "FLUTTER_BUILD_NUMBER=0.1.0"
export "DART_OBFUSCATION=false"
export "TRACK_WIDGET_CREATION=true"
export "TREE_SHAKE_ICONS=false"
export "PACKAGE_CONFIG=.dart_tool/package_config.json"

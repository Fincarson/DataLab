#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=D:\SDK\Flutter\flutter_windows_3.29.0-stable\flutter"
export "FLUTTER_APPLICATION_PATH=D:\GitLab\NTHU_Software_Studion_Wu_ShanHung\2026_Spring\lab-01-flutter-basics-dart-roll-dice-app-example"
export "COCOAPODS_PARALLEL_CODE_SIGN=true"
export "FLUTTER_TARGET=lib\main.dart"
export "FLUTTER_BUILD_DIR=build"
export "FLUTTER_BUILD_NAME=1.0.0"
export "FLUTTER_BUILD_NUMBER=1"
export "DART_OBFUSCATION=false"
export "TRACK_WIDGET_CREATION=true"
export "TREE_SHAKE_ICONS=false"
export "PACKAGE_CONFIG=.dart_tool/package_config.json"

#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=/Users/joselimurty/development/flutter"
export "FLUTTER_APPLICATION_PATH=/Users/joselimurty/Downloads/SS Projects/lab-flutter-basics-dart-expense-tracker"
export "COCOAPODS_PARALLEL_CODE_SIGN=true"
export "FLUTTER_TARGET=/Users/joselimurty/Downloads/SS Projects/lab-flutter-basics-dart-expense-tracker/lib/main.dart"
export "FLUTTER_BUILD_DIR=build"
export "FLUTTER_BUILD_NAME=1.0.0"
export "FLUTTER_BUILD_NUMBER=1"
export "DART_OBFUSCATION=false"
export "TRACK_WIDGET_CREATION=true"
export "TREE_SHAKE_ICONS=false"
export "PACKAGE_CONFIG=/Users/joselimurty/Downloads/SS Projects/lab-flutter-basics-dart-expense-tracker/.dart_tool/package_config.json"
